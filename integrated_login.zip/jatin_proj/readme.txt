This is a login page with movie features
for fully functionality of this page, you have to fill your gmail and app password in
email hot user and email host password in settings.py in movie 
